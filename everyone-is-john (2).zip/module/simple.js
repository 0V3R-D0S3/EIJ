Hooks.once("init", async function() {
  console.log('Everyone is John | Initializing simple system');

  // Register custom system settings
  game.settings.register("everyone-is-john", "johnDescription", {
    name: "John's Description",
    hint: "Describe what John is currently doing.",
    scope: "world",
    config: true,
    type: String,
    default: ""
  });

  // Preload Handlebars templates
  await loadTemplates([
    "systems/everyone-is-john/templates/chat/everyone-is-john.hbs"
  ]);
});
